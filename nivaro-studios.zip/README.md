# Nivaro Studios – Website + Dashboard (Netlify)

**Stack:** statische Seiten (`public/`), Backend = eine Netlify Function (`netlify/functions/api.mjs`), Datenbank = **Netlify Blobs** (in Netlify enthalten, kein Fremdanbieter). E-Mail = SMTP (z. B. STRATO) über `nodemailer`.

## Deployment (Android, nur Browser)
1. ZIP in der Dateien-App entpacken (lange antippen > Extrahieren).
2. github.com > neues **privates** Repository > „Add file > Upload files“ > alle Dateien und Ordner hochladen (Ordnerstruktur beibehalten, `.env.example` ist nur Vorlage).
3. app.netlify.com > „Add new site > Import from Git“ > Repo wählen. Build command leer, Publish directory `public`, Functions `netlify/functions` (steht in `netlify.toml`).
4. Site configuration > **Environment variables**: alle Einträge aus `.env.example` anlegen. Webhook-URLs ausschließlich dort eintragen. Danach „Deploys > Trigger deploy“.
5. Ersteinrichtung: `https://DEINE-SITE/admin.html` > „Ersteinrichtung“ aufklappen > Setup-Token, Benutzername, Passwort (min. 12 Zeichen) und PIN eintragen. Danach das Token `SETUP_TOKEN` in Netlify entfernen oder ändern.
6. Team-Zugänge: Dashboard > Zugänge > Neu (Passwort + PIN + Rechte). Abwählen von „Aktiv“ oder Löschen sperrt sofort.

## Domain nivaro-studios.de (STRATO)
Netlify > Domain management > Add domain. Bei STRATO > Domain > DNS-Einstellungen: A-Record `@` auf die von Netlify angezeigte IP, CNAME `www` auf `DEINE-SITE.netlify.app` (Werte immer aus Netlify übernehmen). Alternativ Nameserver auf Netlify DNS umstellen. HTTPS: Domain management > HTTPS > „Verify DNS / Provision certificate“ (Let’s Encrypt, automatisch).

## Updates
Dateien im GitHub-Repo bearbeiten/ersetzen, Netlify deployt automatisch. Inhalte, Team, Projekte werden im Dashboard geändert, ohne Deploy.

## Wichtig / Grenzen
- **E-Mail:** funktioniert erst mit SMTP-Zugangsdaten. Ob `…@nivaro.studios` existiert, kann ich nicht prüfen; diese Domain unterscheidet sich von `nivaro-studios.de` und muss dir gehören und Postfächer haben.
- Nicht umgesetzt: TOTP-2FA (stattdessen Passwort + PIN), Bild-Upload (nur Bild-URLs), englische Fassung der Rechtstexte, Editor für Webhooks/SMTP im Dashboard (bewusst nur per Umgebungsvariable).
- Blobs ohne Transaktionen: bei gleichzeitigem Speichern kann der letzte Schreibvorgang gewinnen. Für ein kleines Team ausreichend.
- Rechtstexte enthalten Platzhalter und sind keine Rechtsberatung. Netlify-Limits und Preise vor dem Livegang prüfen.
