import {getStore} from "@netlify/blobs";
import {scryptSync,randomBytes,timingSafeEqual,createHmac,createHash} from "node:crypto";
import nodemailer from "nodemailer";
const E=process.env,st=()=>getStore({name:"nivaro",consistency:"strong"});
const rd=async(k,d)=>(await st().get(k,{type:"json"}))??d,wr=(k,v)=>st().setJSON(k,v);
const J=(o,s=200,h={})=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json","cache-control":"no-store",...h}});
const esc=x=>String(x).replace(/[&<>"']/g,c=>"&#"+c.charCodeAt(0)+";");
const s=(v,m)=>typeof v==="string"?v.trim().slice(0,m):"";
const okMail=m=>/^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(m)&&m.length<=120;
const okId=i=>/^\d{17,20}$/.test(i||"");
const rid=()=>randomBytes(6).toString("hex");
const hash=p=>{const salt=randomBytes(16).toString("hex");return{salt,h:scryptSync(p,salt,64).toString("hex")}};
const chk=(p,o)=>!!(o&&o.h&&timingSafeEqual(Buffer.from(o.h,"hex"),scryptSync(p,o.salt,64)));
const sign=v=>createHmac("sha256",E.SESSION_SECRET||"").update(v).digest("base64url");
const mk=u=>{const b=Buffer.from(JSON.stringify({i:u.id,v:u.sv||0,e:Date.now()+12*36e5})).toString("base64url");return b+"."+sign(b)};
async function me(req){const c=(req.headers.get("cookie")||"").match(/nv=([^;]+)/);if(!c||!E.SESSION_SECRET)return null;const[b,g]=c[1].split(".");if(!g||g!==sign(b))return null;let p;try{p=JSON.parse(Buffer.from(b,"base64url"))}catch{return null}if(p.e<Date.now())return null;const u=(await rd("users",[])).find(x=>x.id===p.i);return u&&u.active&&(u.sv||0)===p.v?u:null}
const can=(u,p)=>u.role==="owner"||(u.perms||[]).includes(p);
async function rl(req,key,max,win=36e5){const ip=createHash("sha256").update((req.headers.get("x-nf-client-connection-ip")||"x")+(E.SESSION_SECRET||"")).digest("hex").slice(0,16);const all=await rd("rl",{}),now=Date.now(),k=key+ip;const a=(all[k]||[]).filter(t=>now-t<win);if(a.length>=max)return false;a.push(now);all[k]=a;for(const x in all){all[x]=all[x].filter(t=>now-t<36e5);if(!all[x].length)delete all[x]}await wr("rl",all);return true}
async function hook(env,title,fields,color=0x3b82f6){const u=E[env];if(!u)return;try{await fetch(u,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({embeds:[{title:title.slice(0,250),color,timestamp:new Date().toISOString(),footer:{text:"Nivaro Studios"},fields:fields.map(([n,v])=>({name:n,value:String(v||"–").slice(0,300),inline:true}))}]})})}catch{}}
async function log(type,detail,actor="system"){const l=await rd("logs",[]);l.unshift({t:new Date().toISOString(),type,detail,actor});await wr("logs",l.slice(0,500));await hook("WEBHOOK_ACTIVITY","📋 "+type,[["Akteur",actor],["Details",detail]],0x64748b)}
async function mail(to,subject,html){if(!E.SMTP_HOST||!E.SMTP_USER||!to)return false;try{const p=+E.SMTP_PORT||465;await nodemailer.createTransport({host:E.SMTP_HOST,port:p,secure:p===465,auth:{user:E.SMTP_USER,pass:E.SMTP_PASS}}).sendMail({from:E.MAIL_FROM||E.SMTP_USER,to,subject,html});return true}catch{return false}}
const tpl=(h,b)=>`<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #1e3a8a;border-radius:12px;padding:24px"><h2 style="color:#2563eb;margin:0 0 8px">Nivaro Studios</h2><h3>${h}</h3>${b}<p style="color:#888;font-size:12px">nivaro-studios.de</p></div>`;
const PERMS=["apps","support","team","projects","content","logs"],P={apps:"apps",tickets:"support",team:"team",projects:"projects",settings:"content",users:"owner",logs:"logs"};
const AS=["Eingegangen","In Prüfung","Angenommen","Abgelehnt"],TS=["Offen","In Bearbeitung","Erledigt"];
const FL={team:["fullName","publicName","discordUser","discordId","birth","rank","image","bio","email","notes","joined","active","published"],projects:["title","desc","image","category","link","published"]};
const SK=["discord","supportDiscord","contactEmail","supportMail","heroDe","heroEn"];
export default async(req)=>{
try{
const url=new URL(req.url),path=url.pathname.replace(/^\/api\/?/,"").split("/").filter(Boolean),m=req.method;
if(m!=="GET"&&req.headers.get("x-nv")!=="1")return J({error:"forbidden"},403);
const b=m==="GET"||m==="DELETE"?{}:await req.json().catch(()=>({}));
const now=new Date().toISOString();
if(path[0]==="public"){const[set,team,pr]=await Promise.all([rd("settings",{}),rd("team",[]),rd("projects",[])]);
return J({settings:set,team:team.filter(x=>x.published&&x.active!==false).map(x=>({name:x.publicName,discord:x.discordUser,rank:x.rank,bio:x.bio,email:x.email,image:x.image,link:okId(x.discordId)?"https://discord.com/users/"+x.discordId:""})),projects:pr.filter(x=>x.published).map(({title,desc,image,category,link})=>({title,desc,image,category,link}))})}
if(path[0]==="apply"&&m==="POST"){
if(b.website)return J({ok:true});
if(!await rl(req,"a",5))return J({error:"rate"},429);
const a={id:rid(),created:now,status:"Eingegangen",position:s(b.position,20),user:s(b.user,40),did:s(b.did,20),member:b.member===true,reason:s(b.reason,2000),email:s(b.email,120),lang:b.lang==="en"?"en":"de"};
if(!["Helper","Moderator","Administrator","Developer"].includes(a.position)||!a.user||!okId(a.did)||!a.member||a.reason.length<20||!okMail(a.email)||b.consent!==true)return J({error:"invalid"},400);
const l=await rd("apps",[]);l.unshift(a);await wr("apps",l);
await hook("WEBHOOK_APPS","📨 Neue Bewerbung",[["Position",a.position],["Discord",a.user],["ID",a.id]]);
const de=a.lang==="de";
await mail(E.MAIL_APPS_TO||"Bewerbung@nivaro.studios","Neue Bewerbung: "+a.position,tpl("Neue Bewerbung",`<p><b>${esc(a.position)}</b> – ${esc(a.user)} (${esc(a.did)})<br>${esc(a.email)}</p><p>${esc(a.reason)}</p>`));
await mail(a.email,de?"Deine Bewerbung bei Nivaro Studios":"Your application at Nivaro Studios",tpl(de?"Bewerbung eingegangen":"Application received",de?`<p>Hallo ${esc(a.user)}, danke für deine Bewerbung als ${esc(a.position)}. Wir prüfen sie und melden uns bei dir. Referenz: ${a.id}</p>`:`<p>Hi ${esc(a.user)}, thanks for applying as ${esc(a.position)}. We will review it and get back to you. Reference: ${a.id}</p>`));
return J({ok:true})}
if(path[0]==="support"&&m==="POST"){
if(b.website)return J({ok:true});
if(!await rl(req,"s",5))return J({error:"rate"},429);
const q={id:rid(),created:now,status:"Offen",subject:s(b.subject,120),desc:s(b.desc,3000),user:s(b.user,40),did:s(b.did,20),cat:s(b.cat,20),email:s(b.email,120),lang:b.lang==="en"?"en":"de"};
if(!q.subject||q.desc.length<10||!q.user||!okId(q.did)||!["Server","Bot","Design","Other"].includes(q.cat)||!okMail(q.email)||b.consent!==true)return J({error:"invalid"},400);
const l=await rd("tickets",[]);l.unshift(q);await wr("tickets",l);
await hook("WEBHOOK_SUPPORT","🛟 Neue Supportanfrage",[["Betreff",q.subject],["Kategorie",q.cat],["ID",q.id]],0x22c55e);
const de=q.lang==="de";
await mail(E.MAIL_SUPPORT_TO||"Support@nivaro.studios","Support: "+q.subject,tpl("Neue Supportanfrage",`<p><b>${esc(q.subject)}</b> [${esc(q.cat)}]<br>${esc(q.user)} (${esc(q.did)}) – ${esc(q.email)}</p><p>${esc(q.desc)}</p>`));
await mail(q.email,de?"Deine Supportanfrage bei Nivaro Studios":"Your support request at Nivaro Studios",tpl(de?"Anfrage eingegangen":"Request received",de?`<p>Hallo ${esc(q.user)}, wir haben deine Anfrage „${esc(q.subject)}“ erhalten und melden uns. Referenz: ${q.id}</p>`:`<p>Hi ${esc(q.user)}, we received your request “${esc(q.subject)}”. Reference: ${q.id}</p>`));
return J({ok:true})}
if(path[0]==="setup"&&m==="POST"){const us=await rd("users",[]);if(us.length||!E.SETUP_TOKEN||b.token!==E.SETUP_TOKEN)return J({error:"forbidden"},403);
const un=s(b.username,40).toLowerCase();if(!un||s(b.password,200).length<12||(b.pin&&!/^\d{4,10}$/.test(b.pin)))return J({error:"invalid"},400);
const o={id:rid(),username:un,pw:hash(b.password),role:"owner",perms:[],active:true,sv:0};if(b.pin)o.pin=hash(b.pin);await wr("users",[o]);await log("Inhaber-Konto erstellt","",un);return J({ok:true})}
if(path[0]==="login"&&m==="POST"){
if(!await rl(req,"l",10,9e5))return J({error:"rate"},429);
const un=s(b.username,40).toLowerCase(),u=(await rd("users",[])).find(x=>x.username===un);
const ok=u&&u.active&&chk(String(b.password||""),u.pw)&&(!u.pin||chk(String(b.pin||""),u.pin));
if(!ok){await log("Fehlgeschlagene Anmeldung","Benutzername: "+un.slice(0,30));return J({error:"auth"},401)}
await log("Anmeldung","",u.username);
return J({ok:true},200,{"set-cookie":`nv=${mk(u)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=43200`})}
if(path[0]==="logout")return J({ok:true},200,{"set-cookie":"nv=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0"});
const u=await me(req);
if(!u)return J({error:"auth"},401);
if(path[0]==="me")return J({user:{username:u.username,role:u.role,perms:u.perms||[]}});
if(path[0]!=="admin")return J({error:"nf"},404);
if(path[1]==="export"){if(u.role!=="owner")return J({error:"forbidden"},403);const o={};for(const c of["apps","tickets","team","projects","settings","logs"])o[c]=await rd(c,c==="settings"?{}:[]);o.users=(await rd("users",[])).map(({id,username,role,perms,active})=>({id,username,role,perms,active}));await log("Backup exportiert","",u.username);return J(o)}
const col=path[1],id=path[2];
if(!P[col]||!can(u,P[col]))return J({error:"forbidden"},403);
const ac=u.username;
if(m==="GET"){const d=await rd(col,col==="settings"?{}:[]);return J(col==="users"?d.map(({id,username,role,perms,active})=>({id,username,role,perms,active})):d)}
if(m==="DELETE"){if(col==="settings"||col==="logs")return J({error:"forbidden"},403);const l=await rd(col,[]);const x=l.find(i=>i.id===id);if(!x||x.role==="owner"||x.id===u.id)return J({error:"nf"},404);await wr(col,l.filter(i=>i.id!==id));await log(col+" gelöscht",x.publicName||x.title||x.username||x.id,ac);return J({ok:true})}
if(m==="POST"){
if(col==="settings"){const o={};for(const k of SK){o[k]=s(b[k],k.startsWith("hero")?500:200);if((k==="discord"||k==="supportDiscord")&&o[k]&&!o[k].startsWith("https://"))return J({error:"invalid"},400)}await wr("settings",o);await log("Website-Einstellungen geändert","",ac);return J({ok:true})}
if(col==="apps"||col==="tickets"){const l=await rd(col,[]),x=l.find(i=>i.id===b.id);if(!x)return J({error:"nf"},404);if(!(col==="apps"?AS:TS).includes(b.status))return J({error:"invalid"},400);const old=x.status;x.status=b.status;await wr(col,l);
if(old!==x.status){await log((col==="apps"?"Bewerbung":"Support")+" bearbeitet",`${x.id}: ${old} → ${x.status}`,ac);await hook(col==="apps"?"WEBHOOK_APPS":"WEBHOOK_SUPPORT","🔄 Statusänderung",[["ID",x.id],["Neu",x.status],["Von",ac]],0xf59e0b);
const de=x.lang!=="en";await mail(x.email,de?"Statusänderung – Nivaro Studios":"Status update – Nivaro Studios",tpl(de?"Neuer Status":"New status",`<p>${esc(x.id)}: <b>${esc(x.status)}</b></p>`))}
return J({ok:true})}
if(col==="users"){if(u.role!=="owner")return J({error:"forbidden"},403);const us=await rd("users",[]);let x=us.find(i=>i.id===b.id);const nw=!x;if(nw){const un=s(b.username,40).toLowerCase();if(!un||us.some(i=>i.username===un)||!b.password)return J({error:"invalid"},400);x={id:rid(),username:un,sv:0,role:"member"};us.push(x)}
if(b.password){if(String(b.password).length<10)return J({error:"invalid"},400);x.pw=hash(String(b.password));x.sv++}
if(b.pin){if(!/^\d{4,10}$/.test(b.pin))return J({error:"invalid"},400);x.pin=hash(b.pin);x.sv++}
if(x.role!=="owner"){x.perms=(Array.isArray(b.perms)?b.perms:String(b.perms||"").split(",")).map(p=>p.trim()).filter(p=>PERMS.includes(p));const was=x.active;x.active=b.active===true;if(!x.active&&was!==false)x.sv++}
await wr("users",us);await log(nw?"Zugang erstellt":"Zugang/Rechte geändert",x.username+(x.active?"":" (gesperrt)"),ac);return J({ok:true})}
if(FL[col]){const l=await rd(col,[]);let x=l.find(i=>i.id===b.id);const nw=!x;if(nw){x={id:rid(),created:now};l.unshift(x)}
for(const f of FL[col])if(f in b)x[f]=typeof b[f]==="boolean"?b[f]:s(b[f],["bio","desc","notes"].includes(f)?1000:300);
if(col==="team"&&(!x.publicName||(x.discordId&&!okId(x.discordId))))return J({error:"invalid"},400);
if(col==="projects"&&(!x.title||!["server","bot","design","other"].includes(x.category)))return J({error:"invalid"},400);
await wr(col,l);await log((col==="team"?"Teamprofil ":"Projekt ")+(nw?"erstellt":"geändert"),x.publicName||x.title,ac);return J({ok:true})}}
return J({error:"nf"},404)
}catch(e){return J({error:"server"},500)}};
export const config={path:"/api/*"};
